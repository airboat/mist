/**
@module preloader dapps
*/
require('./browser.js');
